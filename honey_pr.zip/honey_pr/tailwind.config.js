/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./dist/index.html", "./dist/contactus.html" , "./dist/storelocation.html", "./dist/blog.html" ,"./dist/about.html" , "./dist/wishliat.html"],
  theme: {
    fontFamily: {
            'sans':['roboto'] ,
            'serif':['roboto']
    },
    extend: {
      
    },
  },
  plugins: [],
}

